import 'package:flutter/material.dart';
import 'package:next_app/homepage.dart';
import 'package:next_app/questions.dart';

class Quiz extends StatefulWidget {
  const Quiz({super.key});

  @override
  State<Quiz> createState() {
    return _QuizState();
  }
}

class _QuizState extends State<Quiz> {
  var activeScreen = 'home-screen';

   void switchScreen() {
    setState(
      () {
        activeScreen = 'questions-screen';
      },
    );
  }
  // below this code is anothe approach
  // you can use if you wish not to use teniry approach
  // Widget? activeScreen;

  // @override
  // void initState() {
  //   activeScreen = Homepage(switchScreen);

  //   super.initState();
  // }

  // void switchScreen() {
  //   setState(
  //     () {
  //       activeScreen = const Questions();
  //     },
  //   );
  // }

  @override
  Widget build(context) {
    Widget homeWidget = Homepage(switchScreen);
    if (activeScreen == 'questions-screen') {
      homeWidget= const Questions();
    }
          


    return MaterialApp(
      home: Scaffold(
        // backgroundColor: Colors.deepPurpleAccent,

        body: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
            colors: [
              Color.fromARGB(255, 101, 5, 130),
              Color.fromARGB(255, 145, 4, 233),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),),
          // child: activeScreen,
           child: homeWidget
          //  you can use this approach the tinery approach

        //    activeScreen == 
        //   'home-screen'? 
        //   Homepage(switchScreen):
        //    const Questions(),
        // ),
        ),

        // appBar: AppBar(
        //   backgroundColor: Colors.deepPurpleAccent,
      )
    );
  }
}

// body:
// Container(
//   decoration: const BoxDecoration(
//     gradient:LinearGradient(
//       colors: [ Colors.deepPurpleAccent,
//       Color.fromARGB(255, 34, 4, 115) ],
//       begin: Alignment.topLeft,
//       end: Alignment.bottomRight,
//       ),
//   ),
