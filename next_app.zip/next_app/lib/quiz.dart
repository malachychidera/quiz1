import 'package:flutter/material.dart';
import 'package:next_app/homepage.dart';
import 'package:next_app/questions.dart';


class Quiz extends StatefulWidget{
  const Quiz ({super.key});

  @override
  State<Quiz> createState () {
    return _QuizState ();
  }
}


class _QuizState extends State<Quiz> {
  Widget? activeScreen;

  @override
  void initState() {
    
    activeScreen = Homepage(switchScreen);

    super.initState();
  }
   void switchScreen () {
    setState(() {
      activeScreen = const Questions();
    },
    );

   }
  @override
  Widget build (context) {
    return  MaterialApp(
      home: Scaffold(

       // backgroundColor: Colors.deepPurpleAccent,


        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient
             (colors:
              [ Color.fromARGB(255, 187, 8, 241),
             Colors.deepPurpleAccent,

            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            )
          ),
          child: activeScreen,
        ),

        // appBar: AppBar(
        //   backgroundColor: Colors.deepPurpleAccent,
      ),
    );
  }
}


        // body: 
        // Container(
        //   decoration: const BoxDecoration(
        //     gradient:LinearGradient(
        //       colors: [ Colors.deepPurpleAccent, 
        //       Color.fromARGB(255, 34, 4, 115) ],
        //       begin: Alignment.topLeft,
        //       end: Alignment.bottomRight,
        //       ),
        //   ),