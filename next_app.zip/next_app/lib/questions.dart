import 'package:flutter/material.dart';
import 'package:next_app/answer_button.dart';
import 'package:next_app/data/qustions_data.dart';
//import 'package:next_app/models/quiz_questions.dart';


class Questions extends StatefulWidget{
  const Questions ({super.key});

  @override
  State<Questions> createState(){
    return _QuestionsState();
    }
}

class _QuestionsState extends State < Questions>{
  var currentQuestionsIndex = 0;
  
   void answerQuestion () {
    // currentQuestionsIndex = currentQuestionsIndex +1;
    // this is the same thing  with the above
    // currentQuestionsIndex += 1;
    setState(() {
     //  currentQuestionsIndex += 1;
       currentQuestionsIndex++; // increments the value by 1
      
    });
   
  }
  @override
  Widget build (context) {
    final currentQuestions = questions [currentQuestionsIndex];
    return SizedBox(
      width:double.infinity,
      // you can use this as another approach to center your 
      // screen, by using sized boz and double.infinity. the double function is to take any amount of space for your screen.
child: Container (
  margin:const EdgeInsets.all(40),
      child: Column (
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children:[
           Text (currentQuestions.text, 
          style: const TextStyle(
             color: Colors.white),
             textAlign: TextAlign.center,
             ),
          const SizedBox ( height:30),
          ...currentQuestions.getShuffledAnswers().map((answer) {
            return AnswerButton(answerText: answer, onTap: answerQuestion,);
            // this creates list of options that maps out the answer buttons without hardcoding each button like the previous one

          },
          ),
          // AnswerButton (
          //  answerText: currentQuestions.answers [1], 
          //  onTap: () {},),

          //  AnswerButton (
          //  answerText: currentQuestions.answers [2], 
          //  onTap: () {},), 

          //  AnswerButton (
          //  answerText: currentQuestions.answers [3],
          //  onTap: () {},),

          //  AnswerButton (
          //  answerText: currentQuestions.answers [4],
          //  onTap: () {},),
        ],
      ),
),
    );
  }
} 