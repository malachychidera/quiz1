import 'package:flutter/material.dart';
import 'package:next_app/quiz.dart';
// import 'package:next_app/homepage.dart';

void main() {
  runApp( const Quiz()
);
}
