import 'dart:ffi';

import 'package:flutter/material.dart';

class Homepage extends StatelessWidget {
  const Homepage(this.startQuiz, {super.key});
  final Void Function() startQuiz;


  @override
  Widget build(context) {
    return Column( 
      mainAxisSize: MainAxisSize.min,
      children: [
        const Image(
          image: AssetImage('assets/images/quiz-logo.png'),
           width: 250,
           height: 500,
          color: Color.fromARGB(150, 255, 255, 255),
         // alignment: Alignment.bottomCenter,
        ),
         const SizedBox(
          height: 30,
        ),
        const Center(
          child: Text(
            
            'Learn Flutter The Easy Way',
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
              // fontWeight: FontWeight.bold,
            ),
          ),
        ),
        const SizedBox( 
          
          height: 100,
          
        ),
        OutlinedButton.icon(
          style:
           OutlinedButton.styleFrom(
            foregroundColor:
             Colors.white),
          onPressed:startQuiz,
          icon: const Icon(
            Icons.arrow_right
          ),
          label: const Text(
            'Get Started',
          ),
        ),
      ],
    );
  }
}
